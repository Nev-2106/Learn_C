#include <stdio.h>

int countBits(unsigned int i)
{
    ???
}

int main()
{
    for (int i = 0;  i <= 15;  ++i)
        printf("%d\n", countBits(i));

    return 0;
}
