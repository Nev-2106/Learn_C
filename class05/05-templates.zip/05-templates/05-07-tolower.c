#include <stdio.h>

int lower(int c)
{
    ???
}

void toLower(char s[])
{
    ???
}

int main()
{
    char s[] = "Hello World How Are You?";
    toLower(s);
    printf("%s\n", s);
    return 0;
}
