#include <stdio.h>

void squeeze(char s[], int c)
{
    ???
}

int main()
{
    char s[]= "Hello world, how are you?";

    squeeze(s, 'o');
    printf("%s\n", s);

    return 0;
}
